﻿param (
    [Parameter(Mandatory=$false)]
    [string]$Computer,
    [Parameter(Mandatory=$false)]
    [pscredential]$Credential=$null,
    [Parameter(Mandatory=$true)]
    [string]$DeploymentName
)
# TODO: Correct
# $ishBootStrapRootPath=Resolve-Path "$PSScriptRoot\..\.."
$ishBootStrapRootPath="C:\GitHub\ISHBootstrap"

$cmdletsPaths="$ishBootStrapRootPath\Source\Cmdlets"
$scriptsPaths="$ishBootStrapRootPath\Source\Scripts"

. $ishBootStrapRootPath\Examples\Cmdlets\Get-ISHBootstrapperContextValue.ps1
. $ishBootStrapRootPath\Examples\ISHDeploy\Cmdlets\Write-Separator.ps1
Write-Separator -Invocation $MyInvocation -Header -Name "Configure"
. "$cmdletsPaths\Helpers\Get-ProgressHash.ps1"
$scriptProgress=Get-ProgressHash -Invocation $MyInvocation

if(-not $Computer)
{
    & "$scriptsPaths\Helpers\Test-Administrator.ps1"
}

if(-not (Get-Command Invoke-CommandWrap -ErrorAction SilentlyContinue))
{
    . $cmdletsPaths\Helpers\Invoke-CommandWrap.ps1
}        
$webConfigRelativePath=@(
        "Author\ASP\Web.config"
        "InfoShareWS\Web.config"
        "InfoShareSTS\Web.config"
    )

$backupScirptBlock= {
    Backup-ISHDeployment -ISHDeployment $DeploymentName -Path $webConfigRelativePath -Web
}

$customErrorsBlock = {

}

$vbErrorsBlock = {

}

$uncommentSystemDiagnosticsNodeScriptBlock={
    function UncommentSystemDiagnostics($path)
    {
        $commentedNodeName="system.diagnostics"
        Write-Debug "path=$path"
        [xml]$xml=Get-Content -Path $path
        Write-Verbose "Loaded $path"
        $commentedNode = $xml.configuration.SelectNodes("//comment()") | Where-Object -Property InnerText -Match "<$commentedNodeName.*>"
        #$xml.configuration.SelectNodes("//comment()") | Where-Object -Property InnerText -Match "<$commentedNodeName.*>"|Select-Object -ExpandProperty InnerText
        if($commentedNode)
        {
            $tempNode = $xml.CreateElement("TempNodeWrapper")          
            $tempNode.InnerXml = $commentedNode.Value
            $unCommentedNode = $tempNode.SelectSingleNode("/$commentedNodeName")
            $commentedNode.ParentNode.ReplaceChild($unCommentedNode, $commentedNode)|Out-Null
            $xml.Save($path)
            Write-Verbose "Saved $path"
        }
        else
        {
            Write-Verbose "Skipped $path"
        }
    }
    
    $deployment=Get-ISHDeployment -Name $DeploymentName
    $projectSuffix=Get-ISHDeploymentParameters -ISHDeployment $DeploymentName |Where-Object -Property Name -EQ projectSuffix|Select-Object -ExpandProperty Value
    $webPath=Join-Path ($deployment.WebPath) "Web$projectSuffix"
    $webConfigPath=$webConfigRelativePath | ForEach-Object { 
        Join-Path $webPath $_
    }
    $webConfigPath|ForEach-Object {
        UncommentSystemDiagnostics($_)
    }
}

#Install the packages
try
{
    $blockName="Backing up web.config on $DeploymentName"
    Write-Progress @scriptProgress -Status $blockName
    Invoke-CommandWrap -ComputerName $Computer -Credential $Credential -ScriptBlock $backupScirptBlock -BlockName $blockName -UseParameters @("DeploymentName","webConfigRelativePath")

    $blockName="Enabling system.diagnostics on $DeploymentName"
    Write-Progress @scriptProgress -Status $blockName
    Invoke-CommandWrap -ComputerName $Computer -Credential $Credential -ScriptBlock $uncommentSystemDiagnosticsNodeScriptBlock -BlockName $blockName -UseParameters @("DeploymentName","webConfigRelativePath")

    $blockName="Enabling custom errors on $DeploymentName"
    Write-Progress @scriptProgress -Status $blockName
    Invoke-CommandWrap -ComputerName $Computer -Credential $Credential -ScriptBlock $customErrorsBlock -BlockName $blockName -UseParameters @("DeploymentName","webConfigRelativePath")

    $blockName="Enabling visual basic errors on $DeploymentName"
    Write-Progress @scriptProgress -Status $blockName
    Invoke-CommandWrap -ComputerName $Computer -Credential $Credential -ScriptBlock $vbErrorsBlock -BlockName $blockName -UseParameters @("DeploymentName","webConfigRelativePath")
}
finally
{

}

Write-Progress @scriptProgress -Completed
Write-Separator -Invocation $MyInvocation -Footer -Name "Configure"